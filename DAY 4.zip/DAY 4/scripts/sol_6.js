
let num;
do{
    num=(prompt("ENTER A NUMBER GREATER THAN 100"));
}
while(num<=100 || num==" ")
