//GROCERY SHOPPING
//SPREAD OPERATOR
console.log("MY INITIAL CHECKLIST: ");
let shoppingList=["honey","fruits","chocolates","icecream","strawberry","cheese","juice"];
console.log(shoppingList);

console.log("ADD ONS: ");
let shoppingBasket=[...shoppingList,"sweets","tonic","flour","oats","millets"];
console.log(shoppingBasket);